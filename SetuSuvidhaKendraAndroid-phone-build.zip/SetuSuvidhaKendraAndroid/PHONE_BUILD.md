# Build Setu Suvidha Kendra APK using only an Android phone

This project is prepared for a phone-only workflow. You do NOT need Android Studio on your phone.

## Easiest method: GitHub Actions

1. On your Android phone, open GitHub in Chrome and sign in/create a free GitHub account.
2. Create a **new repository** named `SetuSuvidhaKendra`.
3. Upload the contents of this project to the repository. Make sure `.github/workflows/build-apk.yml` is uploaded too.
4. Open the repository → **Actions** → **Build Setu Suvidha Kendra APK**.
5. If needed, tap **Run workflow**.
6. Wait for the workflow to finish with a green check.
7. Open the completed workflow run and scroll to **Artifacts**.
8. Download `SetuSuvidhaKendra-debug-apk`.
9. Extract the downloaded ZIP and install `app-debug.apk` on the phone.
10. If Android blocks installation, enable **Allow from this source** for the browser/file manager you used to download it.

## What the APK contains

- Citizen login (demo)
- Operator login (type `operator` as username)
- Government services
- Online application
- PDF/image document picker
- Local Room database
- Application number generation
- Application tracking
- Demo payment status
- Operator approve/reject

## Important

This is a development/demo APK. Payment is not real, and login is not OTP-based. Documents and applications are stored locally on the device. For production use, connect Firebase/another backend, secure authentication, cloud document storage, and a real UPI/payment gateway.
