# Setu Suvidha Kendra Android App

A phone-friendly Android Studio project for the Setu Suvidha Kendra MVP.

## Phone-only build

You do not need Android Studio on your Android phone. This project includes a GitHub Actions workflow that builds an installable debug APK in the cloud.

See **PHONE_BUILD.md** for the exact steps.

## Features

- Citizen and operator demo login
- Government service catalogue
- Online application form
- PDF/image document upload
- Room local database
- Application tracking
- Demo payment
- Operator approval/rejection

## Demo login

- Citizen: enter any username/mobile
- Operator: enter `operator` as username
- Password is currently not validated in the MVP

## Production upgrade

For real deployment, add OTP authentication, cloud database, secure document storage, real UPI/payment processing, operator/admin accounts, notifications, audit logs, and required government-service integrations.
