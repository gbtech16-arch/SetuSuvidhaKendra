package com.setusuvidhakendra.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "applications")
data class ApplicationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val applicationNo: String,
    val service: String,
    val applicant: String,
    val mobile: String,
    val submittedAt: Long,
    val status: String = "Submitted",
    val paymentStatus: String = "Pending",
    val amount: Int = 50,
    val documentUri: String? = null
)

@Dao
interface ApplicationDao {
    @Query("SELECT * FROM applications ORDER BY submittedAt DESC") fun observeAll(): Flow<List<ApplicationEntity>>
    @Insert suspend fun insert(item: ApplicationEntity): Long
    @Query("UPDATE applications SET status=:status WHERE id=:id") suspend fun updateStatus(id: Long, status: String)
    @Query("UPDATE applications SET paymentStatus='Paid' WHERE id=:id") suspend fun markPaid(id: Long)
    @Query("UPDATE applications SET documentUri=:uri WHERE id=:id") suspend fun setDocument(id: Long, uri: String)
}

@Database(entities = [ApplicationEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun applicationDao(): ApplicationDao
    companion object { @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase = INSTANCE ?: synchronized(this) { INSTANCE ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "setu.db").build().also { INSTANCE = it } }
    }
}
