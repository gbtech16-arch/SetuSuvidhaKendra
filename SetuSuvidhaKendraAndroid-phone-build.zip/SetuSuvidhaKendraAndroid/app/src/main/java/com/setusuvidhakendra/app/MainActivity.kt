package com.setusuvidhakendra.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.setusuvidhakendra.app.data.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { SetuApp() } }
}

@Composable fun SetuApp(vm: AppVM = viewModel()) {
    val nav = rememberNavController(); val apps by vm.apps.collectAsState(initial = emptyList())
    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF1565C0), secondary = androidx.compose.ui.graphics.Color(0xFF2E7D32))) {
        NavHost(navController = nav, startDestination = "login") {
            composable("login") { LoginScreen { vm.login(it); nav.navigate(if (vm.role == "Operator") "operator" else "home") { popUpTo("login") { inclusive = true } } } }
            composable("home") { HomeScreen(apps, nav) }
            composable("services") { ServicesScreen { service -> vm.selectedService = service; nav.navigate("apply") } }
            composable("apply") { ApplyScreen(vm.selectedService, vm, nav) }
            composable("track") { TrackScreen(apps, vm) }
            composable("profile") { ProfileScreen(vm) }
            composable("operator") { OperatorScreen(apps, vm) }
        }
    }
}

class AppVM(app: android.app.Application) : androidx.lifecycle.AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).applicationDao(); val apps = dao.observeAll(); var selectedService = "Income Certificate"; var userName = "Citizen"; var role = "Citizen"
    fun login(name: String) { userName = name.ifBlank { "Citizen" }; role = if (name.lowercase().contains("operator")) "Operator" else "Citizen" }
    suspend fun submit(mobile: String, doc: String?) { dao.insert(ApplicationEntity(applicationNo = "SSK${System.currentTimeMillis().toString().takeLast(8)}", service = selectedService, applicant = userName, mobile = mobile, submittedAt = System.currentTimeMillis(), documentUri = doc)) }
    fun pay(id: Long) = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch { dao.markPaid(id); dao.updateStatus(id, "Under Process") }
    fun status(id: Long, s: String) = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch { dao.updateStatus(id, s) }
    fun document(id: Long, uri: String) = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch { dao.setDocument(id, uri) }
}

@Composable fun TopBar(title: String, onBack: (() -> Unit)? = null) { CenterAlignedTopAppBar(title={Text(title)}, navigationIcon={ if(onBack!=null) IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Back")} }) }

@Composable fun LoginScreen(onLogin:(String)->Unit) { var name by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }; Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) { Text("सेतु सुविधा केंद्र", style=MaterialTheme.typography.headlineMedium); Text("Setu Suvidha Kendra", style=MaterialTheme.typography.titleLarge); Spacer(Modifier.height(24.dp)); OutlinedTextField(name,{name=it},label={Text("Mobile / Username")},modifier=Modifier.fillMaxWidth()); Spacer(Modifier.height(10.dp)); OutlinedTextField(pass,{pass=it},label={Text("Password")},modifier=Modifier.fillMaxWidth()); Spacer(Modifier.height(18.dp)); Button({onLogin(name)},Modifier.fillMaxWidth()){Text("Login")}; Spacer(Modifier.height(10.dp)); Text("Demo: enter any name. Use 'operator' to open operator view.", style=MaterialTheme.typography.bodySmall) } }

@Composable fun HomeScreen(apps:List<ApplicationEntity>, nav:NavHostController) { Scaffold(bottomBar={NavigationBar{ listOf("Home" to Icons.Default.Home,"Services" to Icons.Default.Description,"Track" to Icons.Default.Search,"Profile" to Icons.Default.Person).forEach{(t,i)->NavigationBarItem(selected=false,onClick={nav.navigate(t.lowercase())},icon={Icon(i,t)},label={Text(t)})} }}) { p -> LazyColumn(Modifier.padding(p).padding(16.dp)) { item { Text("सरकारी सेवाएं अब आपके नजदीक", style=MaterialTheme.typography.headlineSmall); Text("Setu Suvidha Kendra", style=MaterialTheme.typography.titleLarge); Spacer(Modifier.height(18.dp)); Card(shape=RoundedCornerShape(18.dp)) { Column(Modifier.padding(18.dp)){Text("Quick Services",style=MaterialTheme.typography.titleLarge); Spacer(Modifier.height(10.dp)); Button({nav.navigate("services")},Modifier.fillMaxWidth()){Text("View All Services")}}}; Spacer(Modifier.height(18.dp)); Text("Your Applications",style=MaterialTheme.typography.titleLarge); if(apps.isEmpty()) item{Text("No applications yet. Start a new service request.",Modifier.padding(vertical=20.dp))} } ; items(apps.take(5)){ a -> ApplicationCard(a, null) } } } }

@Composable fun ServicesScreen(onSelect:(String)->Unit) { val services=listOf("Income Certificate","Caste Certificate","Domicile / Residence Certificate","Birth Certificate","Death Certificate","PAN Related Services","Other Government Services"); Scaffold(topBar={TopBar("Services")}){p->LazyColumn(Modifier.padding(p).padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){items(services){s->Card(onClick={onSelect(s)}){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Description,null); Spacer(Modifier.width(12.dp)); Column{Text(s,style=MaterialTheme.typography.titleMedium);Text("Apply online and track status",style=MaterialTheme.typography.bodySmall)}}}}}}}

@Composable fun ApplyScreen(service:String, vm:AppVM, nav:NavHostController) { var mobile by remember{mutableStateOf("")}; var doc by remember{mutableStateOf<Uri?>(null)}; val scope=rememberCoroutineScope(); val picker=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){doc=it}; Scaffold(topBar={TopBar("Apply Online"){nav.popBackStack()}}){p->Column(Modifier.padding(p).padding(16.dp)){Text(service,style=MaterialTheme.typography.headlineSmall); Text("Required documents",style=MaterialTheme.typography.titleMedium); Text("• Aadhaar / identity proof\n• Supporting document (if applicable)\n• Passport photo"); Spacer(Modifier.height(12.dp)); OutlinedTextField(mobile,{mobile=it},label={Text("Mobile number")},modifier=Modifier.fillMaxWidth()); Spacer(Modifier.height(12.dp)); OutlinedButton({picker.launch(arrayOf("application/pdf","image/*"))},Modifier.fillMaxWidth()){Icon(Icons.Default.AttachFile,null);Spacer(Modifier.width(8.dp));Text(if(doc==null)"Upload Document" else "Document Selected")}; Spacer(Modifier.height(18.dp)); Button({scope.launch{vm.submit(mobile,doc?.toString());nav.navigate("track")}},Modifier.fillMaxWidth(),enabled=mobile.length>=10){Text("Submit Application")}; Spacer(Modifier.height(10.dp)); Text("Service fee: ₹50 (demo)",style=MaterialTheme.typography.bodySmall)}}}

@Composable fun ApplicationCard(a:ApplicationEntity,onPay:(()->Unit)?){ Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(14.dp)){Text(a.service,style=MaterialTheme.typography.titleMedium);Text(a.applicationNo);Text("Status: ${a.status}");Text("Payment: ${a.paymentStatus}"); if(a.paymentStatus!="Paid"&&onPay!=null){Button(onClick=onPay){Text("Pay ₹${a.amount}")}}}} }

@Composable fun TrackScreen(apps:List<ApplicationEntity>, vm:AppVM){Scaffold(topBar={TopBar("Track Application")}){p->LazyColumn(Modifier.padding(p).padding(16.dp)){if(apps.isEmpty())item{Text("No applications found.")}else items(apps){a->ApplicationCard(a, if(a.paymentStatus!="Paid") ({ vm.pay(a.id) }) else null); Text("Submitted → Documents → Under Process → Approved → Ready for Collection",Modifier.padding(bottom=12.dp),style=MaterialTheme.typography.bodySmall)}}}}

@Composable fun ProfileScreen(vm:AppVM){Scaffold(topBar={TopBar("Profile")}){p->Column(Modifier.padding(p).padding(20.dp)){Icon(Icons.Default.AccountCircle,null,Modifier.size(80.dp));Text(vm.userName,style=MaterialTheme.typography.headlineSmall);Text("Role: ${vm.role}");Spacer(Modifier.height(20.dp));Text("My Applications");Text("Application history and notifications are available from the tracking screen.")}}}

@Composable fun OperatorScreen(apps:List<ApplicationEntity>,vm:AppVM){Scaffold(topBar={TopBar("Operator Dashboard")}){p->LazyColumn(Modifier.padding(p).padding(16.dp)){item{Text("Applications",style=MaterialTheme.typography.headlineSmall);Text("Review documents and update status.");Spacer(Modifier.height(12.dp))};items(apps){a->Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(14.dp)){Text(a.applicationNo);Text(a.service);Text(a.applicant);Text("${a.status} • ${a.paymentStatus}");Row{Button({vm.status(a.id,"Approved")}){Text("Approve")};Spacer(Modifier.width(8.dp));OutlinedButton({vm.status(a.id,"Rejected")}){Text("Reject")}}}}}}}}
